#coding=utf-8
#__author__ = 'doriswang'

import os
basedir = os.path.abspath(os.path.dirname(__file__))  # 获得系统路径
CSRF_ENABLED = True
SECRET_KEY = 'i love social network analysis'  # 表单CSRF保护


# 通用配置
class Config:
    CSRF_ENABLED = True
    SECRET_KEY = 'i love social network analysis'  # 表单CSRF保护
    SQLALCHEMY_COMMIT_ON_TEARDOWN = True   # 每次请求结束,自动提交DB的变动

    # 初始化方法,基类为空
    @staticmethod
    def init_app(app):
        pass


class DevelopmentConfig(Config):
    DEBUG = True
    # 配置DB路径,每种配置使用不同环境
    SQLALCHEMY_DATABASE_URI = os.environ.get('DEV_DATABASE_URL') or \
        'sqlite:///' + os.path.join(basedir, 'data-dev.sqlite')


class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = os.environ.get('TEST_DATABASE_URL') or \
        'sqlite:///' + os.path.join(basedir, 'data-test.sqlite')


class ProductionConfig(Config):
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'sqlite:///' + os.path.join(basedir, 'data.sqlite')


# 注册配置环境(字典)
config = {
    'development':DevelopmentConfig,
    'testing':TestingConfig,
    'production':ProductionConfig,

    'default':DevelopmentConfig
}