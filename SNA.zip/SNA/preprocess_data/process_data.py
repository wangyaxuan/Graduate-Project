# coding=utf-8
# __author__ = 'doriswang'

file_name = '22.txt'
input_file = open(file_name, 'r')
output = open('222.txt', 'w')
users = input_file.readlines()
relation_count = 0


for user in users:
    #  thisuser = ',' + user
    user = user.replace(' ', ', ')
    output.write(user)
    relation_count += 1

print(users[1])
input_file.close()
output.close()
