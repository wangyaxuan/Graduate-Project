# coding=utf-8
# __author__ = 'doriswang'
from helloJinja import db, Result
import string


open_result = open('data/6301result.txt', 'r')
open_cost = open('data/6301cost.txt', 'r')
open_select = open('data/6301select.txt', 'r')

results = open_result.readlines()
costs = open_cost.readlines()
select = open_select.readlines()
seedset = [1, 2, 5, 10, 20, 30, 40, 50]
algos = ['bwr', 'tim', 'greedy', 'pagerank', 'random']
algo_count = 0


while algo_count<5:
    result = results[algo_count].split('\t')
    cost = costs[algo_count].split('\t')
    seed_count = 0
    while seed_count < 8:
        this_result = Result(algo_name=algos[algo_count], cost=cost[seed_count], total_inf_value=result[seed_count], seed_num=seed_count)
        if algo_count == 0:
            this_result.seed_set = seedset[7-algo_count]
        else:
            pass
        db.session.add(this_result)
        print('add:' + algos[algo_count])
        seed_count += 1
    algo_count += 1


db.session.commit()

open_result.close()
open_cost.close()
open_select.close()

