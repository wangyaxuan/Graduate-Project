# coding=utf-8
# __author__ = 'doriswang'
from helloJinja import Role, User, db, Relation


file_name = 'data/6301data.txt'
input_file = open(file_name, 'r')

users = input_file.readlines()
relation_count = 0
for user in users:
    if user != '\n':
        user_str = user.split("\t")
        r = Relation(r_in=user_str[0], r_out=user_str[1], r_value=user_str[2])
        db.session.add(r)
        relation_count += 1
    else:
        break


db.session.commit()
print(relation_count)
input_file.close()
