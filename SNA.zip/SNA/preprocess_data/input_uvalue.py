# coding=utf-8
# __author__ = 'doriswang'
from helloJinja import User, db
import string

file_name = 'data/6301value.txt'
input_file = open(file_name, 'r')

values = input_file.readlines()
i = 0
for value in values:
    print(type(value))
    if value != '\n':
        this_value = value[0]
        user = User(username=str(i), value=int(this_value))
        db.session.add(user)
        i += 1
    else:
        break

print(i)
db.session.commit()
input_file.close()

