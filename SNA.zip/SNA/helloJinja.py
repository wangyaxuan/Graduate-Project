# coding=utf-8
# __author__ = 'doriswang'

from flask import Flask, render_template, session, redirect, url_for, flash, Response
from flask_migrate import Migrate, MigrateCommand
from flask_script import Manager
from flask_bootstrap import Bootstrap
from flask_wtf import Form
from flask_mail import Mail
from wtforms import StringField, SubmitField
from wtforms.validators import Required
from flask_sqlalchemy import SQLAlchemy
from flask_script import Shell
from flask_bootstrap import WebCDN
import os


class NameForm(Form):
    name = StringField('What is your name?', validators=[Required()])
    submit = SubmitField('Submit')


app = Flask(__name__)
app.config.from_object('config')

Bootstrap(app)  # 设置前端
app.extensions['bootstrap']['cdns']['jquery'] = WebCDN('//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.1/')

mail = Mail(app)

basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] =\
    'sqlite:///' + os.path.join(basedir, 'data.sqlite')  # 配置数据库 SQLite
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True

db = SQLAlchemy(app)  # 创建SQLAlchemy对象 管理DB事务
migrate = Migrate(app, db)

manager = Manager(app)
manager.add_command('db', MigrateCommand)  # 将MigrateCommand附加到manager对象上.

network = ''


def make_shell_context():
    return dict(app=app, db=db, User=User, Role=Role)
manager.add_command("shell", Shell(make_context=make_shell_context))


class Role(db.Model):
    __tablename__ = 'roles'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True, nullable=True)
    users = db.relationship('User', backref='role',lazy='dynamic')

    def __repr__(self):
        return '<Role %r>' % self.name


#  用户模型
class User(db.Model):
    __tablename__ = 'users'
    uid = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), index=True, nullable=True)
    influence = db.Column(db.Float, index=True, nullable=True)
    value = db.Column(db.Float, index=True)
    nid = db.Column(db.Integer, db.ForeignKey('networks.nid'), nullable=True)  # 指明要引用的外键
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id'))

    def __repr__(self):
        return '<User %r>' % self.username


#  社会图模型
class Network(db.Model):
    __tablename__ = 'networks'
    nid = db.Column(db.Integer, primary_key=True)
    n_name = db.Column(db.String(64), unique=True, index=True, nullable=True)
    type = db.Column(db.Boolean, nullable=True)  # True为有向 False为无向
    users = db.relationship('User', backref='network', lazy='dynamic')  # 标记为 users 的外键
    relations = db.relationship('Relation', backref='network', lazy='dynamic')  # 标记 relations 的外键

    def __repr__(self):
        return '<Network %r>' % self.n_name


#  关系模型
class Relation(db.Model):
    __tablename__ = 'relations'
    rid = db.Column(db.Integer, primary_key=True)
    nid = db.Column(db.Integer, db.ForeignKey('networks.nid'), nullable=True)  # 引用 networks 外键
    r_in = db.Column(db.Integer)  # 引用 users 外键
    r_out = db.Column(db.Integer)  # 引用 users 外键
    r_value = db.Column(db.Float, index=True, nullable=True)

    def __repr__(self):
        return '<Relation %r>' % self.rid


#  结果
class Result(db.Model):
    __tablename__ = 'results'
    result_id = db.Column(db.Integer, primary_key=True)
    algo_name = db.Column(db.String(64))  # algo名字
    cost = db.Column(db.String(64))
    seed_set = db.Column(db.Text, nullable=True)
    seed_num = db.Column(db.Integer)
    total_inf_value = db.Column(db.String(64))
    total_inf_nodes = db.Column(db.String(64), nullable=True)

    def __repr__(self):
        return '<Relation %r>' % self.rid


#  网络模型模型
class SocialNetwork:
    name = network
    max_num = 0
    max_select = 50  # 默认找50个点
    all_users = ['']
    select_list = ['']

    def __init__(self, name):
        self.name = name  #
        self.id = Network.query.filter_by(n_name=name).first()
        all_users = list(User.query.filter_by(nid=self.id))
        max_num = User.query.filter_by(nid=self.id).count()
        select_users = list()


#  html route 索引

#  首页
@app.route('/')
def first():
    return render_template('first.html')


#  index
@app.route('/index', methods=['GET', 'POST'])
def index():
    # name = None
    form = NameForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.name.data).first()
        if user is None:
            user = User(username=form.name.data)
            #  db.session.add(user)
            session['known'] = False
        else:
            session['known'] = True

        session['name'] = form.name.data
        form.name.data = ''
        return redirect(url_for('index'))

    return render_template('index.html', form=form, name=session.get('name'), known = session.get('known', False))


#  test_user
@app.route('/user/<name>')
def user(name):
    return render_template('user.html', name=name)


#  inf 首页
@app.route('/infInput')
def infInput():
    return render_template('infInput.html')


#  inf 进度条
@app.route('/infprocess')
def infprocess():
    return render_template('infprocess.html')


#  inf 进度条
@app.route('/infprocess262')
def infprocess262():
    return render_template('infprocess262.html')


#  inf 结果1
@app.route('/infresult1')
def infresult1():
    return render_template('infresult1.html')


#  inf 结果2
@app.route('/infresult2')
def infresult2():
    return render_template('infresult2.html')


#  inf 结果3
@app.route('/infresult3')
def infresult3():
    return render_template('infresult3.html')


#  inf 结果1
@app.route('/infresult2621')
def infresult2621():
    return render_template('infresult2621.html')


#  email 首页
@app.route('/bwrdetail')
def bwrdetail():
    return render_template('bwrdetail.html')


#  email 首页
@app.route('/bwrdetail262')
def bwrdetail262():
    return render_template('bwrdetail262.html')


#  email 首页
@app.route('/theta')
def theta():
    return render_template('theta.html')



#  email 首页
@app.route('/emailInput')
def emailInput():
    return render_template('emailInput.html')


#  email 首页
@app.route('/nodeDetail')
def node():
    return render_template('nodeDetail.html')


#  email 首页
@app.route('/echarts')
def ec():
    return render_template('echarts.js')


#  email 首页
@app.route('/jquery')
def jq():
    return render_template('jquery.js')


#  email 首页
@app.route('/dataTool')
def dt():
    return render_template('dataTool.min.js')


#  404
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404


#  500
@app.errorhandler(500)
def page_not_found(e):
    return render_template('404.html'),500


if __name__ == '__main__':
    app.run(debug=True)
    manager.run()
