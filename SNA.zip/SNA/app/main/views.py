# coding=utf-8
# __author__ = 'doriswang'

from flask import render_template, session, redirect, url_for

from . import main
from .forms import NameForm
from .. import db
from ..models import User
#from helloJinja import app

#  html route 索引


#  首页
@main.route('/')
def first():
    return render_template('first.html')


#  index
@main.route('/index', methods=['GET', 'POST'])
def index():
    # name = None
    form = NameForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.name.data).first()
        if user is None:
            user = User(username=form.name.data)
            #  db.session.add(user)
            session['known'] = False
        else:
            session['known'] = True

        session['name'] = form.name.data
        form.name.data = ''
        return redirect(url_for('index'))

    return render_template('index.html', form=form, name=session.get('name'), known = session.get('known', False))


#  test_user
@main.route('/user/<name>')
def user(name):
    return render_template('user.html', name=name)


#  inf 首页
@main.route('/infInput')
def infInput():
    return render_template('infInput.html')


#  inf 进度条
@main.route('/infprocess')
def infprocess():
    return render_template('infprocess.html')


#  inf 结果1:算法比较
@main.route('/infresult1')
def infresult1():
    return render_template('infresult1.html')


#  inf 结果2:BWR展示
@main.route('/infresult2')
def infresult2():
    return render_template('infresult2.html')


#  inf 结果3:社区划分
@main.route('/infresult3')
def infresult3():
    return render_template('infresult3.html')


#  email 首页
@main.route('/bwrdetail')
def bwrdetail():
    return render_template('bwrdetail.html')


#  email 首页
@main.route('/emailInput')
def emailInput():
    return render_template('emailInput.html')


#  email 首页
@main.route('/nodeDetail')
def node():
    return render_template('nodeDetail.html')


#  email 首页
@main.route('/echarts')
def ec():
    return render_template('echarts.js')


#  email 首页
@main.route('/jquery')
def jq():
    return render_template('jquery.js')


#  email 首页
@main.route('/dataTool')
def dt():
    return render_template('dataTool.min.js')