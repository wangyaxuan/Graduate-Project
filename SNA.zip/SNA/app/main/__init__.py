# coding=utf-8
# __author__ = 'doriswang'

from flask import Blueprint

main = Blueprint('main', __name__)  # 实例化蓝本

# 加在最后,避免循环导入依赖.(views, errors要import蓝本main)
from . import views, errors
