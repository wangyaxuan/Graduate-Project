# coding=utf-8
# __author__ = 'doriswang'

from app import db

#  用于系统测试,及日后扩展用户角色功能.
class Role(db.Model):
    __tablename__ = 'roles'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True, nullable=True)
    users = db.relationship('User', backref='role',lazy='dynamic')

    def __repr__(self):
        return '<Role %r>' % self.name


#  用户模型
class User(db.Model):
    __tablename__ = 'users'
    uid = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), index=True, nullable=True)
    influence = db.Column(db.Float, index=True, nullable=True)
    value = db.Column(db.Float, index=True)
    nid = db.Column(db.Integer, db.ForeignKey('networks.nid'), nullable=True)  # 指明要引用的外键
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id'))

    def __repr__(self):
        return '<User %r>' % self.username


#  社会图模型
class Network(db.Model):
    __tablename__ = 'networks'
    nid = db.Column(db.Integer, primary_key=True)
    n_name = db.Column(db.String(64), unique=True, index=True, nullable=True)
    type = db.Column(db.Boolean, nullable=True)  # True为有向 False为无向
    users = db.relationship('User', backref='network', lazy='dynamic')  # 标记为 users 的外键
    relations = db.relationship('Relation', backref='network', lazy='dynamic')  # 标记 relations 的外键

    def __repr__(self):
        return '<Network %r>' % self.n_name


#  关系模型
class Relation(db.Model):
    __tablename__ = 'relations'
    rid = db.Column(db.Integer, primary_key=True)
    nid = db.Column(db.Integer, db.ForeignKey('networks.nid'), nullable=True)  # 引用 networks 外键
    r_in = db.Column(db.Integer)  # 引用 users 外键
    r_out = db.Column(db.Integer)  # 引用 users 外键
    r_value = db.Column(db.Float, index=True, nullable=True)

    def __repr__(self):
        return '<Relation %r>' % self.rid


#  结果
class Result(db.Model):
    __tablename__ = 'results'
    result_id = db.Column(db.Integer, primary_key=True)
    algo_name = db.Column(db.String(64))  # algo名字
    cost = db.Column(db.String(64))
    seed_set = db.Column(db.Text, nullable=True)
    seed_num = db.Column(db.Integer)
    total_inf_value = db.Column(db.String(64))
    total_inf_nodes = db.Column(db.String(64), nullable=True)

    def __repr__(self):
        return '<Relation %r>' % self.rid
