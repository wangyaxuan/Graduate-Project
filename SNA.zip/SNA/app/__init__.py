# coding=utf-8
# __author__ = 'doriswang'

from flask import Flask
from flask_bootstrap import Bootstrap
from flask_sqlalchemy import SQLAlchemy
from config import config  # 系统配置总文件

bootstrap = Bootstrap()
db = SQLAlchemy()


def create_app(config_name):
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    config[config_name].init_app(app)

    bootstrap.init_app(app)  # bootstrap引入
    db.init_app(app)  # DB设置

    # 其他自定义配置
    from .main import main as main_blueprint
    from flask import Blueprint
    app.register_blueprint(Blueprint('main', __name__))  # 注册蓝本

    return app
