# coding=utf-8
# __author__ = 'doriswang'


class Node:
    node_ID = 0  #  节点ID
    d_relationships = {}  #  直接可达概率
    all_relationships = {}  #  所有可达概率
    node_value = 0.0  #  节点价值
    node_effect = 0.0  #  节点影响力
    discount = 0.0  #  影响力折减速率


    #  初始化节点
    def __init__(self, id):
        self.node_ID = id


    #  最开始要有的数据是: 两个点之间关系紧密程度 +  一个点最开始的自身价值
    def init_node(self, relationship, value):
        self.d_relationships = relationship
        self.node_value = value
        self.discount = 1.0

    #  最开始要有的数据是: 两个点之间关系紧密程度 +  一个点最开始的自身价值
    def init_passing_probability(self, relationship, value):
        self.d_relationships = relationship
        self.node_value = value
        self.discount = 1.0


    #  def node_gfs:

