# coding=utf-8
# __author__ = 'doriswang'
import unittest
from flask import current_app
from app import create_app, db


#  基本单元测试:项目启动
class BasicTestCase(unittest.TestCase):
    #  项目启动,unittest模块自动加载,在测试前自动执行
    def setUp(self):
        self.app = create_app('testing')
        self.app_context = self.app.app_context()
        self.app_context.push()
        db.create_all()

    #  项目关闭,unittest模块自动加载,在测试结束后自动执行
    def tearDown(self):
        db.session.remove()
        db.drop_all()
        self.app_context.pop()

    def test_app_exists(self):
        self.assertFalse(current_app is None)

    def test_app_is_testing(self):
        self.assertTrue(current_app.config['TESTING'])