#!/usr/bin/python
# -*- coding: utf-8 -*-

import os

result = {}

'''定义一个static统计函数，要求函数能对指定路径，如果是目录能够递归访问，如果是文件就对文件进行行数计算。'''


def static(path='.'):
    if os.path.isdir(path):
        for x in os.listdir(path):
            childdir = os.path.join(path, x)
            if os.path.isdir(childdir):
                static(childdir)
            elif os.path.isfile(childdir):
                clacFilelines(childdir)
    elif os.path.isfile(path):
        clacFilelines(path)
    return


'''实现文件行数计算函数功能，统计文本文件行数，过滤空白行（代码注释涉及到很多情况暂时不处理），并将统计结果保存在以文件扩展名为key的字典result里。'''


def clacFilelines(filepath):
    vpath = os.path.splitext(filepath)
    ext = vpath[1].lower()
    if not ext.strip():
        return False
    if not isTextFile(ext):
        return False
    lines = 0
    with open(filepath, 'rU') as f:
        filelist = f.readlines()
        for line in filelist:
            if not line.strip():
                continue
            lines += 1
        if ext in result:
            result[ext] += lines
        else:
            result[ext] = lines
    print('file:%s lines:%d' % (filepath, lines))
    return True


'''实现文件过滤功能函数，因为文本分为文本文件和二进制文件，对于不符号要求的文件不计算在内。以下是一种较简单的实现方式：'''


def isTextFile(ext):
    tExt = ('.c', '.cpp', '.h', '.py', '.htm', '.html', '.txt', '.lua', '.ini', '.hpp', '.lua', '.cfg')
    if ext in tExt:
        return True
    return False


if __name__ == '__main__':
    print('***********start code line static*************')
    static()
    print('****************static result*****************')
    sum = 0
    for k, v in result.items():
        sum += v
        print('[%s]: %d lines' % (k, v))
    print('total: %d lines' % sum)
    print('******************static end******************')
